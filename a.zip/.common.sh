clear
echo
echo
echo -e "	\033[91m{ 1 }\033[92m Termux os"
echo -e "	\033[91m{ 2 }\033[92m Pip upgrade"
echo -e "	\033[91m{ 3 }\033[92m Install pip3"
echo -e "	\033[91m{ 4 }\033[92m Termux Game"
echo -e "	\033[91m{ 5 }\033[92m Back"
echo -e "	\033[91m{ 6 }\033[92m Exit"
echo
echo -e -n "\033[96m Select >> "
read a
echo -e "\033[91m Invalid Input !!"
if [ "$a" = "1" ];then
cd $HOME
bash .Termux_os.sh
fi
if [ "$a" = "2" ];then
clear
apt update
apt upgrade
pip --upgrade pip
pip2 --upgrade pip
fi
if [ "$a" = "3" ];then
clear
apt remove python
apt install python
clear
echo -e "\033[92m success"
fi
if [ "$a" = "4" ];then
cd $HOME
bash .Game.sh
fi
if [ "$a" = "5" ];then
cd $HOME
bash .bashr*
fi