
clear
clear





















































#sleep 0.2
#sleep 0.3
#sleep 0.1











































































clear
clear
#list
#list
#list
#list
#list
#list
#list
clear
clear
clear
clear
clear









#add hp jao button
#add hone ka option aao
#1st
#2nd
#3rd
#4rth
#5th
#6th
#ab sab add ho jayega
#bhut Aasan hai
#add ho gya






#end
#end





















#end
#end
#end
#end
#end
#end






































#end
#end






































































































#end ho gya
#ab niche
#or niche




















#kuch hai niche


















































































#kya kr rhe ho



































#chan nhi aa rha




































#mar jao chan nhi aa rha hai to

















































#hi

























#hello

















#ek song hai
































































#padho










#o padh ke hi rhoge




















#thik hai padh lo
































#lekin achha nhi lagega



















































#to nhi manoge padhoge hi



































































































































#




#
##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
##cuma selingkuhan kamu
#aku mah apa atuh
##cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu













#kuch samjh nhi aaya hoga




















#
#😀😀😀😀😀😀😀😀

#ye indonesia song hai 
#sun k dekho
















#youtube me search kro



























##aku mah apa atuh












#or sun ke dwkho achha


#lagega

clear
clear





#end





#kahani khatam





##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
##cuma selingkuhan kamu
#aku mah apa atuh
##cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu



















##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
##cuma selingkuhan kamu
#aku mah apa atuh
##cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu
clear
clear
clear
clear
clear


















#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#e
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#































clear
clear





















































#sleep 0.2
#sleep 0.3
#sleep 0.1
































clear
clear





















































#sleep 0.2
#sleep 0.3
#sleep 0.1











































































clear
clear
#list
#list
#list
#list
#list
#list
#list
clear
clear
clear
clear
clear









#add hp jao button
#add hone ka option aao
#1st
#2nd
#3rd
#4rth
#5th
#6th
#ab sab add ho jayega
#bhut Aasan hai
#add ho gya






#end
#end





















#end
#end
#end
#end
#end
#end






































#end
#end






































































































#end ho gya
#ab niche
#or niche




















#kuch hai niche


















































































#kya kr rhe ho



































#chan nhi aa rha




































#mar jao chan nhi aa rha hai to

















































#hi

























#hello

















#ek song hai
































































#padho










#o padh ke hi rhoge




















#thik hai padh lo
































#lekin achha nhi lagega



















































#to nhi manoge padhoge hi



































































































































#




#
##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu













#kuch samjh nhi aaya hoga




















#
#😀😀😀😀😀😀😀😀

#ye indonesia song hai 
#sun k dekho
















#youtube me search kro



























##aku mah apa atuh












#or sun ke dwkho achha


#lagega

clear
clear





#end





#kahani khatam





##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu



















##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu
clear
clear
clear
clear
clear


















#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#e
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#































clear
clear





















































#sleep 0.2
#sleep 0.3
#sleep 0.1











































































clear
clear
#list
#list
#list
#list
#list
#list
#list
clear
clear
clear
clear
clear









#add hp jao button
#add hone ka option aao
#1st
#2nd
#3rd
#4rth
#5th
#6th
#ab sab add ho jayega
#bhut Aasan hai
#add ho gya






#end
#end





















#end
#end
#end
#end
#end
#end






































#end
#end






































































































#end ho gya
#ab niche
#or niche




















#kuch hai niche


















































































#kya kr rhe ho



































#chan nhi aa rha




































#mar jao chan nhi aa rha hai to

















































#hi

























#hello

















#ek song hai
































































#padho










#o padh ke hi rhoge




















#thik hai padh lo
































#lekin achha nhi lagega



















































#to nhi manoge padhoge hi



































































































































#




#
##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu













#kuch samjh nhi aaya hoga




















#
#😀😀😀😀😀😀😀😀

#ye indonesia song hai 
#sun k dekho
















#youtube me search kro



























##aku mah apa atuh












#or sun ke dwkho achha


#lagega

clear
clear





#end





#kahani khatam





##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu



















##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu
clear
clear
clear
clear
clear


















#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#e
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#


































	













































clear
clear
#list
#list
#list
#list
#list
#list
#list
clear
clear
clear
clear
clear









#add hp jao button
#add hone ka option aao
#1st
#2nd
#3rd
#4rth
#5th
#6th
#ab sab add ho jayega
#bhut Aasan hai
#add ho gya






#end
#end





















#end
#end
#end
#end
#end
#end






































#end
#end






































































































#end ho gya
#ab niche
#or niche




















#kuch hai niche


















































































#kya kr rhe ho



































#chan nhi aa rha




































#mar jao chan nhi aa rha hai to

















































#hi

























#hello

















#ek song hai
































































#padho










#o padh ke hi rhoge




















#thik hai padh lo
































#lekin achha nhi lagega



















































#to nhi manoge padhoge hi



































































































































#




#
##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu













#kuch samjh nhi aaya hoga




















#
#😀😀😀😀😀😀😀😀

#ye indonesia song hai 
#sun k dekho
















#youtube me search kro



























##aku mah apa atuh












#or sun ke dwkho achha


#lagega

clear
clear





#end





#kahani khatam





##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu



















##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu
clear
clear





















































#sleep 0.2
#sleep 0.3
#sleep 0.1











































































clear
clear
#list
#list
#list
#list
#list
#list
#list
clear
clear
clear
clear
clear









#add hp jao button
#add hone ka option aao
#1st
#2nd
#3rd
#4rth
#5th
#6th
#ab sab add ho jayega
#bhut Aasan hai
#add ho gya






#end
#end





















#end
#end
#end
#end
#end
#end






































#end
#end






































































































#end ho gya
#ab niche
#or niche




















#kuch hai niche


















































































#kya kr rhe ho



































#chan nhi aa rha




































#mar jao chan nhi aa rha hai to

















































#hi

























#hello

















#ek song hai
































































#padho










#o padh ke hi rhoge




















#thik hai padh lo
































#lekin achha nhi lagega



















































#to nhi manoge padhoge hi



































































































































#




#
##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu













#kuch samjh nhi aaya hoga




















#
#😀😀😀😀😀😀😀😀

#ye indonesia song hai 
#sun k dekho
















#youtube me search kro



























##aku mah apa atuh












#or sun ke dwkho achha


#lagega

clear
clear





#end





#kahani khatam





##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
#cuma selingkuhan kamu
#aku mah apa atuh
#cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu

#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma pacar gelapmu
#aku mah apa atuh, #cuma selingkuhan kamu
#aku mah apa atuh, #cuma cadanganmu



















##Kapanlagi Plus
#hi
 
 

 
#aku mah apa atuh
##cuma selingkuhan kamu
#aku mah apa atuh
##cuma pacar gelapmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu

#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu
clear
clear
clear
clear
clear


















#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#e
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#



































#sakit hatiku #kau acuhkan #aku
#kau tak peduli denganku
#kau bagi cintamu, #kau permainkanku
#kau berbuat semaumu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu

#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma pacar gelapmu
#aku mah apa atuh, ##cuma selingkuhan kamu
#aku mah apa atuh, ##cuma cadanganmu
clear
clear
clear
clear
clear


















#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
##kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#e
#kuch nhi hai
#kya
#button
#add
c="clear"
#ye hai
#short v hai
e="echo -e"
#ye likhne k liye hai
nhipta="\033[95m"
#agr kuch likhna ho to ye pryog karna hota hai
#kya
s="echo -e -n"
#ajib hai ye v
rang="\033[42m"
#ye to or jyada ajib hai
#ye rang hua to nmbr kon sa hua
#pura ajib
#All button ab jodayega
likho="All button added successfull"
#folder v bnana hoga
#to fir bnate hai folder
bnao="mkdir"
khatam="\033[0m"
#bna liye folder
#ab kuch or krenge
#ab folder delete krenge
#nhi
#file delete krte hai
delete="rm -f"
#ab delete ho gya
#bhut jyada line ho gya
#32line ho gya
#ajib hai
#jitna likhe sab green color ho rha
#rang bdlne wala nmbr likhte hai
hara="\033[92m"
#ye hara rang hoga
pila="\033[93m"
#yad rakhna hai
#ye pila rang hoga
lal="\033[91m"
#ye wala lal rang hoga mtlb red color
#yad rakhna ye lal ka hai
bulu="\033[94m"
#ye wala se bulu hoga mtlb blue hpga hqm yahi dekhe hai
#ye wala se blue hi hota hai samjh me aaya na ye kya hai
ajib="\033[96m"
#ye kaisa rang hai nhi pta isliye hm ajib bolte hai sayad sky
#lekin bhut
#jagah dekhe hai
#ise cyan bolte hai
#pr cyan kya hota hai wo nhi pta
#ab or kya krna hai
#ab anumati v de dete hai
anumati="termux-setup-storage"
#ye wala se anumati milta hai
#yad rakho
#yad rakhna hi pdega
#bhut jagah jarurat pad jata hai
#ye wala se button jodana chahiye
#
#
#
#
#
#
#
#
#
#
#
#
#ye krne me achha lagta hai niche krte rho
#achha
#lagega
#kya kya
#likhe
#hai
#samjh me
#aayega
#niche dekhte jao
#ab copy
#karna chahiye
#copy kar k paste krne me achha
#lgta hai
#dekho niche ya upar 
#copy hoga
#
#
#
#
#
#
#
#
#
#
#






























































































#
$c
$e "$rang Enter Button Name$khatam"
echo
$s "$lal 1st : "
read a
if [ ! -z $a ];then
$s "$hara 2nd : "
fi
read b
if [ ! -z $b ];then
$s "$pila 3rd : "
fi
read c
if [ ! -z $c ];then
$s "$bulu 4th : "
fi
read d
if [ ! -z $d ];then
$s "$nhipta 5th : "
fi
read e
if [ ! -z $e ];then
$s "$ajib 6th : "
fi
read f
if [ ! -z $f ];then
echo
$anumati
$delete $HOME/.termux/termux.properties
$bnao $HOME/.termux
echo "extra-keys = [['/','CTRL','ENTER','*','LEFT','.','RIGHT'],['$a','$b','$c','$d','$e','DOWN','$f']]" >> $HOME/.termux/termux.properties
echo -e " $a $b $c $d $e $f "
echo "$likho"
fi
