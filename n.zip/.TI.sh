ho () {
	echo
	echo -e "Press enter to home"|lolcat
	read
	TI
	}
	fake-else () {
		cd ~/Termux-New-Look-Installed
		if [ -e .fake-storage ];then
		rm -Rf .fake2 >> /dev/null 2>&1
		mkdir .fake2
		cp -f .c.sh ~/Termux-New-Look-Installed/.fake2
		cd .fake2
		bash .c.sh
		else
		echo
		fi
		}
		el () {
			cd ~/Termux-New-Look-Installed
			if [ -e .c.sh ];then
			echo
			else
			unzip b.zip
			fi
			}
		
		
ip () {
	printf "Your Ip :- "|lolcat
	curl ifconfig.me
	echo
	echo -e "Press enter to home"|lolcat
	read
	TI
	}
	T-Storage () {
		clear
		cd $HOME
		du -hs *|sort -rf|head -800|lolcat
		echo
		du -hs
		ho
		}
		I-Storage () {
			clear
			cd /sdcard
			du -hs *|sort -rf | head -10000 |lolcat
			echo
			du -hs
			ho
			}
			T-Tool () {
				clear
				printf " Your Termux Tool Info \n"|lolcat
				cd $HOME
				ls -a --full-time|lolcat
				echo
				printf "without color press enter"
				read
				ls -a --full-time
				ho
				}
				phone () {
					clear
					screenfetch
					echo
					neofetch
					ho
					}
					filter () {
						toilet -F list
						ho
						}
						export () {
							toilet -E list
							ho
							}
							full-s () {
								cd ~/Termux-New-Look-Installed
								el
								bash .b.sh
								ho
								}
								arch () {
									printf "Your architecture :- "|lolcat
									dpkg --print-architecture
									ho
									}
									kernal () {
										print " Your Version :- \n\n"
										uname -a
										}
										full-fake () {
											cd ~/Termux-New-Look-Installed
											el
											termux-setup-storage
											fake-else
											mkdir .fake-storage
											cp -f .c.sh ~/Termux-New-Look-Installed/.fake-storage
											cd .fake-storage
											bash .c.sh
											ho
											}
TI () {
cd ~/Termux-New-Look-Installed
hara="\033[92m"
lal="\033[91m"
sada="\033[97m"
pila="\033[93m"
toilet -F metal Termux-New-Look-Installed
echo
printf "	$hara [ $sada 1 $hara ] $pila Your ip\n"
printf "	$hara [ $sada 2 $hara ] $pila Termux-storage\n"
printf "	$hara [ $sada 3 $hara ] $pila internal storage info\n"
printf "	$hara [ $sada 4 $hara ] $pila Kernal version\n"
printf "	$hara [ $sada 5 $hara ] $pila Termux-Tool Info\n"
printf "	$hara [ $sada 6 $hara ] $pila phone info\n"
printf "	$hara [ $sada 7 $hara ] $pila Your architecture\n"
printf "	$hara [ $sada 8 $hara ] $pila Toilet filter list\n"
printf "	$hara [ $sada 9 $hara ] $pila Toilet export list\n"
printf "	$hara [ $sada 10 $hara ] $pila Storage full\n"
printf "	$hara [ $sada 11 $hara ] $pila Termux-Fake-Storage \n"
printf "	$hara [ $sada 12 $hara ] $pila Exit\n\n\n"
echo -e -n "\033[93m TI@(\033[91m Script\033[93m ) >>  "
read a
case $a in
1)ip ;;
2)T-Storage ;;
3)I-Storage ;;
4)kernal ;;
5)T-Tool ;;
6)phone ;;
7)arch ;;
8)filter ;;
9)export ;;
10)full-s ;;
11)full-fake ;;
12)exit ;;
*)TI ;;
esac
}
TI