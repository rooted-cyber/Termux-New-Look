Decompile () {
	clear
 	printf "\n \033[93m Copy .apk in $HOME/apktool\n"
 	read
 	cd $HOME
 	cd ~/apktool
 	apktool d *.apk
 	printf "\n \033[93m [√] Success Decompile\n"
 	style
 	}
 
 Recompile () {
	clear
	printf "\n\n \033[93m Recompile .apk please wait....\n"
	cd ~/apktool
	folder
	}
	
	folder () {
		
		echo -e -n "\033[92m Enter decompiled folder name :- "
		read f
		if [ ! -z $f ];then
		cd ~/apktool
		apktool b $f --output new.apk
		printf "\033[92m\n [√] Sucessfully Recompile your apk\n"
		sleep 2
		printf "\033[96m\n\n [+] Now apksinger your apk......"
		apksigner -p 12345 keystore new.apk new-signer.apk
		cp -f new-signer.apk /sdcard/Apktool
		echo
		printf "\n\033[92m \n[√] Successfully Recompiled .apk in /sdcard/Apktool\n"
		style
		fi
		}
		
start_apktool () {
	style
	echo
	printf "	\033[91m [ 1 ]\033[92m Decompile apk\n"
	printf "	\033[91m [ 2 ]\033[92m Recompile apk\n\n\033[96m"
	printf %s "Select >> "
	read ab
	case $ab in
	1|01) Decompile ;;
	2|02) Recompile ;;
	esac
	}
	style () {
		figlet Apktool|toilet -f term -F gay
		}
not_setup () {
	cd $HOME
	start_apktool
	}
setup () {
	clear
	style
	mkdir /sdcard/Apktool
	cd $HOME
	mkdir apktool
	cd apktool
	wget https://github.com/rooted-cyber/upload-apktool/raw/master/apktool_2.3.4_all.deb
	dpkg -i apktool*
	clear
	printf "\033[96m Press enter to start apktool menu"
	read
	cd $HOME
	start_apktool
	}
clear
echo -e -n "\033[92m	 Installatin Requirements ?\033[91m (\033[96m y/n\033[91m) "
read apk
case $apk in
 y|Y) setup ;;
 n|N) not_setup ;;
 esac
