snake () {
	cd $HOME
	python2 snk.py
	}

gam () {
	clear
	printf "\033[91m	[ 1 ]\033[92m Tetris\n"
	printf "\033[91m	[ 2 ]\033[92m Moon-Buggy\n"
	printf "\033[91m	[ 3 ]\033[92m Snake\n"
	printf "\033[91m	[ 4 ]\033[92m Home\n\n"
	printf %s "Select >> "
	read game
	case $game in
	1)bastet ;;
	2)moon-buggy ;;
	3)snake ;;
	4)bash ;;
	esac
	}
clear
echo -e "\033[1;96m====================================================="
echo -e "\033[1;92m			Termux Game			"
echo -e "\033[1;96m====================================================="
echo
echo
echo -e "\e[96m		==========================="
echo -e "		\e[91m【 1 】\e[92m Termux Game Install"
echo -e "\e[96m		==========================="
echo -e "		\e[91m【 2 】\e[92m Termux Game Play"
echo -e "\e[96m		==========================="
echo -e "		\e[91m【 3 】\e[92m Main Menu"
echo -e "\e[96m		==========================="
echo
echo -e -n "\033[95m Type your option ## "
read maruf
if [ "$maruf" = "1" ];then
clear
clear
clear
cd ~
apt update
apt upgrade
apt-get install moon-buggy
apt-get install bastet
apt-get install game-repo
wget https://github.com/rooted-cyber/good/raw/master/snk.py > /dev/null 2>&1
clear
echo "	[~] Successfully Installed"
fi
if [ "$maruf" = "2" ];then
clear
gam
fi
if [ "$maruf" = "3" ];then
clear
clear
cd $HOME
bash .bashr*
fi
