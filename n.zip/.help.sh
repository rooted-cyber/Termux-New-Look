h() {
	clear
	printf "\n\033[92m
	Tool installation command
	
	
	Commands		Meaning\n"
	printf "\033[0m
	saycheese		Saycheese install & open
	shellphish		Shellphish install & open
	sayhello		Sayhello install & open
	H-Cam			H-Cam install & open
	hiddeneye		HiddenEye install & open
	tbomb			TBomb install & open
	amer			Amer virus install & open
	B-Crash			B-Crash install & open
	C-Fish			C-Fish install & open
	seeker-2		Seeker-2 install & open
	Apktool			Apktool install & open
	MBOMB			MBOMB-V2 install & open
	Download-App		Download-App install & open
	Metasploit		Metasploit-Installation Tool install & open
	ngrok			Download ngrok and install in bin"
	printf "\n\n\033[96m
	Command for installing pkg :-
	
	Commands			Meaning\n\033[0m"
	printf "
	toilet			Install & use toilet
	figlet			Install & use figlet"
	}
	h